= Faker

A port of Perl's Data::Faker library that generates fake data.

== Usage
* Faker::Name.name => "Christophe Bartell"

* Faker::Internet.email => "kirsten.greenholt@corkeryfisher.info"